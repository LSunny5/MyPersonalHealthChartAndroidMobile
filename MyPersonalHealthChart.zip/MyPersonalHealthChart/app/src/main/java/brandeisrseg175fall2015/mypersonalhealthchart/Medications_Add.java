package brandeisrseg175fall2015.mypersonalhealthchart;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Medications_Add extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.medicationsadd);
    }






}
