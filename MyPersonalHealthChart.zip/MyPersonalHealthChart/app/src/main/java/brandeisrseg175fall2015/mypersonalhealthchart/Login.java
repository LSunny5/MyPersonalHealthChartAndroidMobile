package brandeisrseg175fall2015.mypersonalhealthchart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    DatabaseHelper helper = new DatabaseHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void buttonClick(View v){
        if (v.getId() == R.id.SigninButton){
            EditText name = (EditText) findViewById(R.id.Username);
            String n = name.getText().toString();
            EditText pass = (EditText) findViewById(R.id.Password);
            String p = pass.getText().toString();

            String checkpass = helper.searchPass(n);



        //    if (n == null){
         //       Toast.makeText(Login.this, "No user name!", Toast.LENGTH_LONG).show();
          //  }else

            if (p.equals(checkpass)) {
                Intent i = new Intent(Login.this, Home.class);
                i.putExtra("uname", n);
                startActivity(i);
            }else{
                //alert
                Toast t = Toast.makeText(Login.this, "Password does not match!", Toast.LENGTH_LONG);
                t.show();
            }

            //Check pass and username match

        }




        //make Account
        if (v.getId() == R.id.AccountButton){
            Intent i = new Intent(Login.this, CreateAccount.class);
            startActivity(i);
        }



        //No Account
        if (v.getId() == R.id.SkipArrow){
            Intent i = new Intent(Login.this, Home.class);
            i.putExtra("uname", "User");
            startActivity(i);
        }





    }


}

