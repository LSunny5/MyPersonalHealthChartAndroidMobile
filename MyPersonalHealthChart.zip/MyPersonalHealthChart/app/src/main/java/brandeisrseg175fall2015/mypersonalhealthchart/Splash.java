package brandeisrseg175fall2015.mypersonalhealthchart;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Sunny on 10/28/2015.
 */

public class Splash extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Thread thread = new Thread() {
            public void run() {
                try {
                    sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    Intent i = new Intent(Splash.this, Login.class);
                    startActivity(i);
                }
            }
        };
        thread.start();


    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}


        /**
        Thread myThread = new Thread() {
            @Override
            public void run() {
                try {
                    sleep(3000);
                    Intent startApp = new Intent(getApplicationContext(), Login.class);
                    Splash.this.startActivity(startApp);
                    Splash.this.finish();


                    //overridePendingTransition(R.anim.fadein, R.anim.fadeout);


                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        myThread.start();


         }
    }**/
