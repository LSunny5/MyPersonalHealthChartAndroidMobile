package brandeisrseg175fall2015.mypersonalhealthchart;

import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class Summary extends AppCompatActivity {
    //private ListView SummaryList = (ListView) findViewById(R.id.SummaryList);
   // private ArrayAdapter<String> SummaryListAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        //create and show custom toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);

        //setup back arrow
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //list of Summary items
        //SummaryList = (ListView) findViewById(R.id.SummaryList);
        //String [] summary = new String[] {"11/1/2015:  Flu Shot", "12/10/2015: Surgery"};
        //ArrayList<String> sumList = new ArrayList<String>();
        //sumList.addAll(Arrays.asList(summary));

        //ArrayAdapter
        //SummaryListAdapter = new ArrayAdapter<String>(this, R.layout.summaryrow, sumList);
        //SummaryList.setAdapter(SummaryListAdapter);

        //Add other items
       // SummaryListAdapter.add("1/2/2016:  Physical Therapy");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //if hamburger icon selected
        if (id == R.id.options) {
            Toast.makeText(Summary.this, "Not yet implemented", Toast.LENGTH_LONG).show();
            return true;
        }
        //if back arrow selected
        if (id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask(this);
        }
        return super.onOptionsItemSelected(item);
    }

}