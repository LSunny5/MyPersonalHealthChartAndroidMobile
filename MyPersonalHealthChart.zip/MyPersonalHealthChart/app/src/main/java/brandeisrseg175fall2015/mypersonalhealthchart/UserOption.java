package brandeisrseg175fall2015.mypersonalhealthchart;

import android.content.Intent;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;


public class UserOption extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_option);

        //create and show custom toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);

        //setup back arrow
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();

        //if hamburger icon selected
        if (id == R.id.options)
        {
            Toast.makeText(UserOption.this, "Not yet implemented", Toast.LENGTH_LONG).show();
            return true;
        }
        //if back arrow selected
        if (id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask(this);
        }
        return super.onOptionsItemSelected(item);
    }

    //selections of buttons
    public void buttonClick (View v) {
        if (v.getId() == R.id.MedHisButton) {
            Intent i = new Intent(UserOption.this, MedicalHistory.class);
            startActivity(i);
        }
        if (v.getId() == R.id.FamHisButton) {
            Intent i = new Intent(UserOption.this, FamilyHistory.class);
            startActivity(i);
        }
        if (v.getId() == R.id.ImmunButton) {
            Intent i = new Intent(UserOption.this, Immunization.class);
            startActivity(i);
        }
        if (v.getId() == R.id.MedButton) {
            Intent i = new Intent(UserOption.this, Medications.class);
            startActivity(i);
        }
        if (v.getId() == R.id.AllergiesButton) {
            Intent i = new Intent(UserOption.this, Allergies.class);
            startActivity(i);
        }
        if (v.getId() == R.id.TestsButton) {
            Intent i = new Intent(UserOption.this, Tests.class);
            startActivity(i);
        }
        if (v.getId() == R.id.SummaryButton) {
            Intent i = new Intent(UserOption.this, Summary.class);
            startActivity(i);
        }
        if (v.getId() == R.id.InsButton) {
            Intent i = new Intent(UserOption.this, Insurance.class);
            startActivity(i);
        }
        if (v.getId() == R.id.NotesButton) {
            Intent i = new Intent(UserOption.this, Notes.class);
            startActivity(i);
        }
    }
}