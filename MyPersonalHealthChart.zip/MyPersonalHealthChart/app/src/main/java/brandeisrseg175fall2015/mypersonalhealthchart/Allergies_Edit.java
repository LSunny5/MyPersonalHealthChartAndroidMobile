package brandeisrseg175fall2015.mypersonalhealthchart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Toast;

public class Allergies_Edit extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.allergiesedit);

        //popup window set
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        getWindow().setLayout((int) (width * 0.8), (int) (height * 0.8));
    }

    //if confirmed
    public void onClick (View v){
        if (v.getId() == R.id.confirmButton){
            //add allergy to list

            Toast.makeText(Allergies_Edit.this, "Confirmed", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(this, Allergies.class);
            startActivity(i);
        }


        //cancel adding note
        if (v.getId() == R.id.CancelButton){
            Intent i = new Intent(this, Allergies.class);
            startActivity(i);
        }
    }


}
