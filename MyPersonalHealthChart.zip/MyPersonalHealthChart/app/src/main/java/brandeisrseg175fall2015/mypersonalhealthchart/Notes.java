package brandeisrseg175fall2015.mypersonalhealthchart;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Notes extends AppCompatActivity {
    private ArrayList<String> notes = new ArrayList<String>();
    private ListView NotesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        //create and show custom toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.app_bar);
        setSupportActionBar(toolbar);

        //setup back arrow
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        //example notes
        notes.add("item 1");
        notes.add("item 2");
        notes.add("item 3");


        //list of notes items
        NotesList = (ListView) findViewById(R.id.NotesList);
        NotesList.setAdapter(new NotesAdapter(this, R.layout.notesitem, notes));




        //expand list and react to clicking list item
        NotesList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void  onItemClick (AdapterView<?> parent, View view, int position, long id){
                Toast.makeText(Notes.this, "clicked for now, need to change to expand", Toast.LENGTH_SHORT).show();
            }

        });






    }

    //adding new note and listitem
    public void addClick (View v){
        if (v.getId() == R.id.AddButton){
            Intent i = new Intent(this, Notes_Add.class);
            startActivity(i);
        }
    }

    //delete a note






    //use regular toolbar for action bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    //add items to menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //if hamburger icon selected
        if (id == R.id.options) {
            Toast.makeText(Notes.this, "Not yet implemented", Toast.LENGTH_LONG).show();
            return true;
        }
        //if back arrow selected
        if (id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask(this);
        }
        return super.onOptionsItemSelected(item);
    }

    //adding notes layout view
    private class NotesAdapter extends ArrayAdapter<String> {
        private int layout;

        private NotesAdapter(Context context, int resource, List<String> objects) {
            super(context, resource, objects);
            layout = resource;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder mainViewHolder = null;
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from(getContext());
                convertView = inflater.inflate(layout, parent, false);
                ViewHolder viewholder = new ViewHolder();
                viewholder.editB = (ImageButton) convertView.findViewById(R.id.NotesItemEditButton);
                viewholder.note = (TextView) convertView.findViewById(R.id.NotesItemText);
                viewholder.editB.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(getContext(), "Clicked Edit Button", Toast.LENGTH_SHORT).show();
                        // change layout and function to delete



                    }
                });
                convertView.setTag(viewholder);
            }
            else {
                mainViewHolder = (ViewHolder) convertView.getTag();
                mainViewHolder.note.setText(getItem(position));
            }
            return convertView;
        }
    }



    public class ViewHolder {
        TextView note;
        ImageButton editB;
    }
}//end of Notes.java