package brandeisrseg175fall2015.mypersonalhealthchart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Toast;

public class Notes_Add extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notesadd);

        //popup window set
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        int width = dm.widthPixels;
        int height = dm.heightPixels;
        getWindow().setLayout((int) (width * 0.8), (int) (height * 0.2));


        
    }

    //adding new note and listitem
    public void onClick (View v) {
        if (v.getId() == R.id.OkayButton) {


            //txtInput=(EditText) findViewById (R.id.txtInput);
            //Button btadd = (Button) findViewById(R.id.btadd);
            //btAdd.setOnClickListener(new View.OnClickListener(){
            //@Override
            //public void onClick(View v){
            //String newItem= txtInput.getText().toString();
            //arrayList.add(newItem);
            //adapter.notifyDataSetChanged();

       //     notes.add("First Item is equal to a long sentence that is used for testing while the second one is short");
         //   notes.add("Second Item");
           // notes.add("why does this not work");


            Toast.makeText(Notes_Add.this, "Added new note!", Toast.LENGTH_SHORT).show();

            Intent i = new Intent(this, Notes.class);
            startActivity(i);

        }

        //cancel adding note
        if (v.getId() == R.id.OkayButton) {
            Intent i = new Intent(this, Notes.class);
            startActivity(i);
        }
    }

}
