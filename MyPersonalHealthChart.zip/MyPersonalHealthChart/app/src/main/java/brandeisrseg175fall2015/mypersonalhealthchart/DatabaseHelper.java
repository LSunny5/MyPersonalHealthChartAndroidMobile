package brandeisrseg175fall2015.mypersonalhealthchart;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/** Used instructions from https://www.youtube.com/watch?v=NT1qxmqH1eM&index=13&list=PLzV8uWUcseN8x0c3q2hRx9X4vbLYSlipb **/

public class DatabaseHelper extends SQLiteOpenHelper {


    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "users.db";
    private static final String TABLE_NAME = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_DOB = "dob";
    private static final String COLUMN_BLOOD = "blood";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASS = "pass";



    SQLiteDatabase db;

    private static final String TABLE_CREATE = "create table users (id integer primary key not null , " +
            "name text not null, dob text not null, blood text not null, username text not null, pass text not null);";


    public DatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        this.db = db;
    }



    public void insertUser(User u) {
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        String query = "select * from users";
        Cursor cursor = db.rawQuery(query, null);
        int count = cursor.getCount();




        values.put(COLUMN_ID, count);
        values.put(COLUMN_NAME, u.getName());
        values.put(COLUMN_DOB, u.getDob());
        values.put(COLUMN_BLOOD, u. getBloodtype());
        values.put(COLUMN_USERNAME, u.getUsername());
        values.put(COLUMN_PASS, u. getPass());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }




    public String searchUser (String username) {
        db = this.getReadableDatabase();
        String query = "select username, pass from " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);
        String u = "not found";

        if (cursor.moveToFirst()) {
            do {
                u = cursor.getString(0);

                if (u.equals(username)) {
                    username = cursor.getString(1);
                    break;
                }
            } while (cursor.moveToNext());
        }
        return u;
    }

    public String searchPass (String username) {
        db = this.getReadableDatabase();
        String query = "select username, pass from " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);
        String u, p;
        p = "not found";

        if (cursor.moveToFirst()) {
            do {
                u = cursor.getString(0);

                if (u.equals(username)) {
                    p = cursor.getString(1);
                    break;
                }
            } while (cursor.moveToNext());
        }
        return p;
    }









    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS " + TABLE_NAME;
        db.execSQL(query);
        this.onCreate(db);
    }
}
